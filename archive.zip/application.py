from os import lseek
from app import application, db

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    db.create_all()
    # app.run(debug=True, port=8000, host='127.0.0.1')
    application.run()